import ValentineProposal from "@/components/ValentineProposal";

export default function Home() {
  return (
    <main>
      <ValentineProposal />
    </main>
  );
}
